// DataTable + Export Excel / PDF
$(document).ready(function() {
    var table = $('#dataTable').DataTable({
        dom: 'Bfrtip', // B = Buttons
        buttons: [
            {
                extend: 'excelHtml5',
                title: 'Rekap Data User',
                className: 'd-none' // tombol bawaan disembunyikan
            },
            {
                extend: 'pdfHtml5',
                title: 'Rekap Data User',
                className: 'd-none', // tombol bawaan disembunyikan
                orientation: 'portrait',
                pageSize: 'A4'
            }
        ]
    });

    $('#btnExcel').on('click', function() {
        table.button(0).trigger();
    });

    $('#btnPdf').on('click', function() {
        table.button(1).trigger();
    });
});